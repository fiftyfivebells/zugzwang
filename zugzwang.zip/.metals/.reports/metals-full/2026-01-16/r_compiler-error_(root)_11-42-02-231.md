error id: 1AF0C115F0B829796E05463A2493EE87
file://<WORKSPACE>/src/main/scala/com/ffb/zugzwang/board/Board.scala
### java.lang.AssertionError: assertion failed

occurred in the presentation compiler.



action parameters:
uri: file://<WORKSPACE>/src/main/scala/com/ffb/zugzwang/board/Board.scala
text:
```scala
package com.ffb.zugzwang.board

import scala.collection.immutable.ArraySeq
import com.ffb.zugzwang.chess.{Color, Piece, PieceType, Square}
import scala.collection.mutable
import com.ffb.zugzwang.move.{Attacks, Move, MoveType}

enum PieceCategory:
  case WP, WN, WB, WR, WQ, WK, BP, BN, BB, BR, BQ, BK

object PieceCategory:
  def of(piece: Piece): PieceCategory = piece match {
    case Piece(Color.White, PieceType.Pawn)   => WP
    case Piece(Color.White, PieceType.Knight) => WN
    case Piece(Color.White, PieceType.Bishop) => WB
    case Piece(Color.White, PieceType.Rook)   => WR
    case Piece(Color.White, PieceType.Queen)  => WQ
    case Piece(Color.White, PieceType.King)   => WK
    case Piece(Color.Black, PieceType.Pawn)   => BP
    case Piece(Color.Black, PieceType.Knight) => BN
    case Piece(Color.Black, PieceType.Bishop) => BB
    case Piece(Color.Black, PieceType.Rook)   => BR
    case Piece(Color.Black, PieceType.Queen)  => BQ
    case Piece(Color.Black, PieceType.King)   => BK
  }

  def byColor(c: Color): List[PieceCategory] = c match {
    case Color.White =>
      List(
        PieceCategory.WP,
        PieceCategory.WN,
        PieceCategory.WB,
        PieceCategory.WR,
        PieceCategory.WQ,
        PieceCategory.WK
      )
    case Color.Black =>
      List(
        PieceCategory.BP,
        PieceCategory.BN,
        PieceCategory.BB,
        PieceCategory.BR,
        PieceCategory.BQ,
        PieceCategory.BK
      )
  }
end PieceCategory

final case class Board private (
    pieces: IArray[Bitboard],
    squares: ArraySeq[Option[Piece]]
):

  // TODO: this is not the most "functional" implementation, so maybe I'll revisit this
  // and try to do this in a nicer way later on. it works for now though
  def toFen: String =
    val fenString = new mutable.StringBuilder("")

    for (rank <- 8 to 1 by -1) {
      var emptySquares = 0
      var startingSquare = rank * 8 - 1

      for (i <- startingSquare to startingSquare - 7 by -1) {
        squares(i) match {
          case None => emptySquares += 1
          case Some(p) =>
            if emptySquares > 0 then
              fenString.append(emptySquares.toString)
              emptySquares = 0

            fenString.append(p.toString)
        }
      }

      if emptySquares > 0 then fenString.append(emptySquares.toString)

      fenString.append("/")
    }

    fenString.dropRight(1).toString

  def occupied: Bitboard = pieces.foldLeft(Bitboard.empty)(_ | _)

  def byColor(c: Color): Bitboard =
    PieceCategory.byColor(c).foldLeft(Bitboard.empty) { (bb, pc) =>
      bb | pieces(pc.ordinal)
    }

  def byColorAndType(c: Color, pt: PieceType): Bitboard =
    val piece = Piece(c, pt)
    val pc = PieceCategory.of(piece)

    pieces(pc.ordinal)

  def allPieces: List[Piece] = squares.flatMap(identity).toList

  def clearBoard: Board = Board.empty

  def pieceAt(sq: Square): Option[Piece] = squares(sq.value)

  def putPieceAt(p: Piece, sq: Square): Board =
    val pieceIndex = PieceCategory.of(p).ordinal
    val newBitboard = pieces(pieceIndex).setBitAt(sq)

    Board(
      pieces.updated(pieceIndex, newBitboard),
      squares.updated(sq.value, Some(p))
    )

  def removePieceFrom(sq: Square): Board =
    squares(sq.value) match {
      case None => this
      case Some(piece) =>
        val pieceIndex = PieceCategory.of(piece).ordinal
        val newBitboard = pieces(pieceIndex).clearBitAt(sq)
        val newSquares = squares.updated(sq.value, None)

        Board(pieces.updated(pieceIndex, newBitboard), newSquares)
    }

  def isKingAttacked(c: Color): Boolean =
    val kingIndex =
      if c == Color.White then PieceCategory.WK else PieceCategory.BK

    val kingSquare = pieces(kingIndex.ordinal).leastSignificantBit

    kingSquare match
      case Some(square) => isAttacked(square, c)

      // if we can't find the king, then there's a bigger problem, but since that's unlikely
      // I'm just going to mark it as false
      case None => false

  def isAttacked(sq: Square, c: Color): Boolean =
    val enemy = c.enemy

    PieceCategory.byColor(c).foldLeft(false) { (isAttacked, pc) =>
      val piece = Piece.from(pc)
      val attackMask = Attacks.attacks(piece, sq, this.occupied)

      isAttacked || (attackMask & byColorAndType(
        enemy,
        piece.pieceType
      )).nonEmpty
    }

  private def pieceToCategory(p: Piece): PieceCategory = p match
    case Piece(Color.White, PieceType.Pawn)   => PieceCategory.WP
    case Piece(Color.White, PieceType.Knight) => PieceCategory.WN
    case Piece(Color.White, PieceType.Bishop) => PieceCategory.WB
    case Piece(Color.White, PieceType.Rook)   => PieceCategory.WR
    case Piece(Color.White, PieceType.Queen)  => PieceCategory.WQ
    case Piece(Color.White, PieceType.King)   => PieceCategory.WK
    case Piece(Color.Black, PieceType.Pawn)   => PieceCategory.BP
    case Piece(Color.Black, PieceType.Knight) => PieceCategory.BN
    case Piece(Color.Black, PieceType.Bishop) => PieceCategory.BB
    case Piece(Color.Black, PieceType.Rook)   => PieceCategory.BR
    case Piece(Color.Black, PieceType.Queen)  => PieceCategory.BQ
    case Piece(Color.Black, PieceType.King)   => PieceCategory.BK

end Board

object Board:

  def empty: Board =
    Board(IArray.fill(12)(Bitboard.empty), ArraySeq.fill(64)(None))

  def initial: Board =
    Board.from("rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR")

  def from(fen: String): Board =
    val fenNoDashes = fen.replaceAll("/", "")
    val fenNoNumbers =
      fenNoDashes
        .map(ch => if ch.isDigit then "*" * ch.asDigit else ch.toString)
        .mkString

    fenNoNumbers.zipWithIndex.foldLeft(Board.empty) { (bb, pair) =>
      val (c, i) = pair
      val index = 63 - i
      if c == '*' then bb
      else
        val piece = Piece.from(c)

        Square.from(index) match {
          case Some(square) => bb.putPieceAt(piece, square)
          case None         => bb
        }
    }

  def applyMove(board: Board, move: Move): Board = move.moveType match {
    case MoveType.CastleKingside | MoveType.CastleQueenside =>
      applyCastleMove(board, move)

    case MoveType.EnPassant =>
      val piece = board.pieceAt(move.from).get
      val epSquare = piece.color match {
        case Color.White => Square(move.to.value - 8)
        case Color.Black => Square(move.to.value + 8)
      }

      board
        .removePieceFrom(move.from)
        .removePieceFrom(epSquare)
        .putPieceAt(piece, move.to)

    case _ =>
      (board.pieceAt(move.from), move.promotion) match
        // this should never happen, but if the piece at the from square is None, just
        // return the original board unaltered
        case (None, _) => board

        case (Some(moving), None) =>
          board
            .removePieceFrom(move.to)
            .removePieceFrom(move.from)
            .putPieceAt(moving, move.to)

        case (Some(pawn), Some(promotion)) =>
          val promoPiece = Piece(pawn.color, promotion)
          board
            .removePieceFrom(move.to)
            .removePieceFrom(move.from)
            .putPieceAt(promoPiece, move.to)
  }

  private def applyCastleMove(board: Board, move: Move): Board =
    board.pieceAt(move.from) match {
      // as above, this should never happen, but if we try to apply a castle and there's
      // no king at the from square, just return the board and we'll catch the issue later
      case None => board
      case Some(king) =>
        val rook = Piece(king.color, PieceType.Rook)

        val (kingTo, rookFrom, rookTo) = move.moveType match {
          case MoveType.CastleKingside =>
            if king.color == Color.White then (Square.G1, Square.H1, Square.F1)
            else (Square.G8, Square.H8, Square.F8)

          case MoveType.CastleQueenside =>
            if king.color == Color.White then (Square.C1, Square.A1, Square.D1)
            else (Square.C8, Square.A8, Square.D8)

          // this is another just in case; this really shouldn't ever happen, I just
          // didn't want warnings about non-exhaustive matches
          case _ => (Square.A1, Square.A1, Square.A1)
        }

        board
          .removePieceFrom(move.from)
          .removePieceFrom(rookFrom)
          .putPieceAt(king, kingTo)
          .putPieceAt(rook, rookTo)
    }

end Board

```


presentation compiler configuration:
Scala version: 3.3.1
Classpath:
<WORKSPACE>/.bloop/root/bloop-bsp-clients-classes/classes-Metals-pKzJapwxSEmeMUWl9fN_WQ== [exists ], <HOME>/.cache/bloop/semanticdb/com.sourcegraph.semanticdb-javac.0.11.0/semanticdb-javac-0.11.0.jar [exists ], <HOME>/.cache/coursier/v1/https/repo1.maven.org/maven2/org/scala-lang/scala3-library_3/3.3.1/scala3-library_3-3.3.1.jar [exists ], <HOME>/.cache/coursier/v1/https/repo1.maven.org/maven2/org/openjdk/jmh/jmh-core/1.37/jmh-core-1.37.jar [exists ], <HOME>/.cache/coursier/v1/https/repo1.maven.org/maven2/org/openjdk/jmh/jmh-generator-bytecode/1.37/jmh-generator-bytecode-1.37.jar [exists ], <HOME>/.cache/coursier/v1/https/repo1.maven.org/maven2/org/openjdk/jmh/jmh-generator-reflection/1.37/jmh-generator-reflection-1.37.jar [exists ], <HOME>/.cache/coursier/v1/https/repo1.maven.org/maven2/org/scala-lang/modules/scala-parallel-collections_3/1.0.4/scala-parallel-collections_3-1.0.4.jar [exists ], <HOME>/.cache/coursier/v1/https/repo1.maven.org/maven2/org/scala-lang/scala-library/2.13.10/scala-library-2.13.10.jar [exists ], <HOME>/.cache/coursier/v1/https/repo1.maven.org/maven2/net/sf/jopt-simple/jopt-simple/5.0.4/jopt-simple-5.0.4.jar [exists ], <HOME>/.cache/coursier/v1/https/repo1.maven.org/maven2/org/apache/commons/commons-math3/3.6.1/commons-math3-3.6.1.jar [exists ], <HOME>/.cache/coursier/v1/https/repo1.maven.org/maven2/org/openjdk/jmh/jmh-generator-asm/1.37/jmh-generator-asm-1.37.jar [exists ], <HOME>/.cache/coursier/v1/https/repo1.maven.org/maven2/org/ow2/asm/asm/9.0/asm-9.0.jar [exists ]
Options:
-Xsemanticdb -sourceroot <WORKSPACE>




#### Error stacktrace:

```
scala.runtime.Scala3RunTime$.assertFailed(Scala3RunTime.scala:11)
	dotty.tools.dotc.core.TypeOps$.dominators$1(TypeOps.scala:248)
	dotty.tools.dotc.core.TypeOps$.approximateOr$1(TypeOps.scala:382)
	dotty.tools.dotc.core.TypeOps$.orDominator(TypeOps.scala:395)
	dotty.tools.dotc.core.Types$OrType.join(Types.scala:3435)
	dotty.tools.dotc.core.Types$OrType.widenUnionWithoutNull(Types.scala:3451)
	dotty.tools.dotc.core.Types$Type.widenUnion(Types.scala:1296)
	dotty.tools.dotc.core.ConstraintHandling.widenOr$1(ConstraintHandling.scala:652)
	dotty.tools.dotc.core.ConstraintHandling.widenInferred(ConstraintHandling.scala:668)
	dotty.tools.dotc.core.ConstraintHandling.widenInferred$(ConstraintHandling.scala:29)
	dotty.tools.dotc.core.TypeComparer.widenInferred(TypeComparer.scala:30)
	dotty.tools.dotc.core.ConstraintHandling.instanceType(ConstraintHandling.scala:707)
	dotty.tools.dotc.core.ConstraintHandling.instanceType$(ConstraintHandling.scala:29)
	dotty.tools.dotc.core.TypeComparer.instanceType(TypeComparer.scala:30)
	dotty.tools.dotc.core.TypeComparer$.instanceType(TypeComparer.scala:3010)
	dotty.tools.dotc.core.Types$TypeVar.instantiate(Types.scala:4809)
	dotty.tools.dotc.typer.Inferencing.tryInstantiate$1(Inferencing.scala:738)
	dotty.tools.dotc.typer.Inferencing.doInstantiate$1(Inferencing.scala:741)
	dotty.tools.dotc.typer.Inferencing.interpolateTypeVars(Inferencing.scala:744)
	dotty.tools.dotc.typer.Inferencing.interpolateTypeVars$(Inferencing.scala:559)
	dotty.tools.dotc.typer.Typer.interpolateTypeVars(Typer.scala:116)
	dotty.tools.dotc.typer.Typer.simplify(Typer.scala:3128)
	dotty.tools.dotc.typer.Typer.typedUnadapted(Typer.scala:3114)
	dotty.tools.dotc.typer.Typer.typedUnnamed$1(Typer.scala:3096)
	dotty.tools.dotc.typer.Typer.typedUnadapted(Typer.scala:3112)
	dotty.tools.dotc.typer.Typer.typed(Typer.scala:3184)
	dotty.tools.dotc.typer.Typer.typed(Typer.scala:3188)
	dotty.tools.dotc.typer.Typer.traverse$1(Typer.scala:3237)
	dotty.tools.dotc.typer.Typer.typedStats(Typer.scala:3256)
	dotty.tools.dotc.typer.Typer.typedBlockStats(Typer.scala:1159)
	dotty.tools.dotc.typer.Typer.typedBlock(Typer.scala:1163)
	dotty.tools.dotc.typer.Typer.typedUnnamed$1(Typer.scala:3056)
	dotty.tools.dotc.typer.Typer.typedUnadapted(Typer.scala:3112)
	dotty.tools.dotc.typer.Typer.typed(Typer.scala:3184)
	dotty.tools.dotc.typer.Typer.typed(Typer.scala:3188)
	dotty.tools.dotc.typer.Typer.typedExpr(Typer.scala:3300)
	dotty.tools.dotc.typer.Namer.typedAheadExpr$$anonfun$1(Namer.scala:1653)
	dotty.tools.dotc.typer.Namer.typedAhead(Namer.scala:1643)
	dotty.tools.dotc.typer.Namer.typedAheadExpr(Namer.scala:1653)
	dotty.tools.dotc.typer.Namer.valOrDefDefSig(Namer.scala:1709)
	dotty.tools.dotc.typer.Namer.defDefSig(Namer.scala:1789)
	dotty.tools.dotc.typer.Namer$Completer.typeSig(Namer.scala:791)
	dotty.tools.dotc.typer.Namer$Completer.completeInCreationContext(Namer.scala:934)
	dotty.tools.dotc.typer.Namer$Completer.complete(Namer.scala:814)
	dotty.tools.dotc.core.SymDenotations$SymDenotation.completeFrom(SymDenotations.scala:174)
	dotty.tools.dotc.core.Denotations$Denotation.completeInfo$1(Denotations.scala:187)
	dotty.tools.dotc.core.Denotations$Denotation.info(Denotations.scala:189)
	dotty.tools.dotc.core.SymDenotations$SymDenotation.ensureCompleted(SymDenotations.scala:393)
	dotty.tools.dotc.typer.Typer.retrieveSym(Typer.scala:2989)
	dotty.tools.dotc.typer.Typer.typedNamed$1(Typer.scala:3014)
	dotty.tools.dotc.typer.Typer.typedUnadapted(Typer.scala:3111)
	dotty.tools.dotc.typer.Typer.typed(Typer.scala:3184)
	dotty.tools.dotc.typer.Typer.typed(Typer.scala:3188)
	dotty.tools.dotc.typer.Typer.traverse$1(Typer.scala:3210)
	dotty.tools.dotc.typer.Typer.typedStats(Typer.scala:3256)
	dotty.tools.dotc.typer.Typer.typedBlockStats(Typer.scala:1159)
	dotty.tools.dotc.typer.Typer.typedBlock(Typer.scala:1163)
	dotty.tools.dotc.typer.Typer.typedUnnamed$1(Typer.scala:3056)
	dotty.tools.dotc.typer.Typer.typedUnadapted(Typer.scala:3112)
	dotty.tools.dotc.typer.Typer.typed(Typer.scala:3184)
	dotty.tools.dotc.typer.Typer.typed(Typer.scala:3188)
	dotty.tools.dotc.typer.Typer.typedFunctionValue(Typer.scala:1626)
	dotty.tools.dotc.typer.Typer.typedFunction(Typer.scala:1377)
	dotty.tools.dotc.typer.Typer.typedUnnamed$1(Typer.scala:3058)
	dotty.tools.dotc.typer.Typer.typedUnadapted(Typer.scala:3112)
	dotty.tools.dotc.typer.ProtoTypes$FunProto.$anonfun$7(ProtoTypes.scala:495)
	dotty.tools.dotc.typer.ProtoTypes$FunProto.cacheTypedArg(ProtoTypes.scala:418)
	dotty.tools.dotc.typer.ProtoTypes$FunProto.typedArg(ProtoTypes.scala:496)
	dotty.tools.dotc.typer.Applications$ApplyToUntyped.typedArg(Applications.scala:897)
	dotty.tools.dotc.typer.Applications$ApplyToUntyped.typedArg(Applications.scala:897)
	dotty.tools.dotc.typer.Applications$Application.addTyped$1(Applications.scala:589)
	dotty.tools.dotc.typer.Applications$Application.matchArgs(Applications.scala:653)
	dotty.tools.dotc.typer.Applications$Application.init(Applications.scala:492)
	dotty.tools.dotc.typer.Applications$TypedApply.<init>(Applications.scala:779)
	dotty.tools.dotc.typer.Applications$ApplyToUntyped.<init>(Applications.scala:896)
	dotty.tools.dotc.typer.Applications.ApplyTo(Applications.scala:1126)
	dotty.tools.dotc.typer.Applications.ApplyTo$(Applications.scala:352)
	dotty.tools.dotc.typer.Typer.ApplyTo(Typer.scala:116)
	dotty.tools.dotc.typer.Applications.simpleApply$1(Applications.scala:969)
	dotty.tools.dotc.typer.Applications.realApply$1$$anonfun$2(Applications.scala:1052)
	dotty.tools.dotc.typer.Typer.tryEither(Typer.scala:3324)
	dotty.tools.dotc.typer.Applications.realApply$1(Applications.scala:1063)
	dotty.tools.dotc.typer.Applications.typedApply(Applications.scala:1101)
	dotty.tools.dotc.typer.Applications.typedApply$(Applications.scala:352)
	dotty.tools.dotc.typer.Typer.typedApply(Typer.scala:116)
	dotty.tools.dotc.typer.Typer.typedUnnamed$1(Typer.scala:3048)
	dotty.tools.dotc.typer.Typer.typedUnadapted(Typer.scala:3112)
	dotty.tools.dotc.typer.Typer.typedUnnamed$1(Typer.scala:3096)
	dotty.tools.dotc.typer.Typer.typedUnadapted(Typer.scala:3112)
	dotty.tools.dotc.typer.Typer.typed(Typer.scala:3184)
	dotty.tools.dotc.typer.Typer.typed(Typer.scala:3188)
	dotty.tools.dotc.typer.Typer.traverse$1(Typer.scala:3237)
	dotty.tools.dotc.typer.Typer.typedStats(Typer.scala:3256)
	dotty.tools.dotc.typer.Typer.typedBlockStats(Typer.scala:1159)
	dotty.tools.dotc.typer.Typer.typedBlock(Typer.scala:1163)
	dotty.tools.dotc.typer.Typer.typedUnnamed$1(Typer.scala:3056)
	dotty.tools.dotc.typer.Typer.typedUnadapted(Typer.scala:3112)
	dotty.tools.dotc.typer.Typer.typed(Typer.scala:3184)
	dotty.tools.dotc.typer.Typer.typed(Typer.scala:3188)
	dotty.tools.dotc.typer.Typer.typedExpr(Typer.scala:3300)
	dotty.tools.dotc.typer.Typer.$anonfun$57(Typer.scala:2486)
	dotty.tools.dotc.inlines.PrepareInlineable$.dropInlineIfError(PrepareInlineable.scala:243)
	dotty.tools.dotc.typer.Typer.typedDefDef(Typer.scala:2486)
	dotty.tools.dotc.typer.Typer.typedNamed$1(Typer.scala:3024)
	dotty.tools.dotc.typer.Typer.typedUnadapted(Typer.scala:3111)
	dotty.tools.dotc.typer.Typer.typed(Typer.scala:3184)
	dotty.tools.dotc.typer.Typer.typed(Typer.scala:3188)
	dotty.tools.dotc.typer.Typer.traverse$1(Typer.scala:3210)
	dotty.tools.dotc.typer.Typer.typedStats(Typer.scala:3256)
	dotty.tools.dotc.typer.Typer.typedClassDef(Typer.scala:2669)
	dotty.tools.dotc.typer.Typer.typedTypeOrClassDef$1(Typer.scala:3036)
	dotty.tools.dotc.typer.Typer.typedNamed$1(Typer.scala:3040)
	dotty.tools.dotc.typer.Typer.typedUnadapted(Typer.scala:3111)
	dotty.tools.dotc.typer.Typer.typed(Typer.scala:3184)
	dotty.tools.dotc.typer.Typer.typed(Typer.scala:3188)
	dotty.tools.dotc.typer.Typer.traverse$1(Typer.scala:3210)
	dotty.tools.dotc.typer.Typer.typedStats(Typer.scala:3256)
	dotty.tools.dotc.typer.Typer.typedPackageDef(Typer.scala:2812)
	dotty.tools.dotc.typer.Typer.typedUnnamed$1(Typer.scala:3081)
	dotty.tools.dotc.typer.Typer.typedUnadapted(Typer.scala:3112)
	dotty.tools.dotc.typer.Typer.typed(Typer.scala:3184)
	dotty.tools.dotc.typer.Typer.typed(Typer.scala:3188)
	dotty.tools.dotc.typer.Typer.typedExpr(Typer.scala:3300)
	dotty.tools.dotc.typer.TyperPhase.typeCheck$$anonfun$1(TyperPhase.scala:44)
	dotty.tools.dotc.typer.TyperPhase.typeCheck$$anonfun$adapted$1(TyperPhase.scala:54)
	scala.Function0.apply$mcV$sp(Function0.scala:42)
	dotty.tools.dotc.core.Phases$Phase.monitor(Phases.scala:440)
	dotty.tools.dotc.typer.TyperPhase.typeCheck(TyperPhase.scala:54)
	dotty.tools.dotc.typer.TyperPhase.runOn$$anonfun$3(TyperPhase.scala:88)
	scala.runtime.function.JProcedure1.apply(JProcedure1.java:15)
	scala.runtime.function.JProcedure1.apply(JProcedure1.java:10)
	scala.collection.immutable.List.foreach(List.scala:333)
	dotty.tools.dotc.typer.TyperPhase.runOn(TyperPhase.scala:88)
	dotty.tools.dotc.Run.runPhases$1$$anonfun$1(Run.scala:246)
	scala.runtime.function.JProcedure1.apply(JProcedure1.java:15)
	scala.runtime.function.JProcedure1.apply(JProcedure1.java:10)
	scala.collection.ArrayOps$.foreach$extension(ArrayOps.scala:1321)
	dotty.tools.dotc.Run.runPhases$1(Run.scala:262)
	dotty.tools.dotc.Run.compileUnits$$anonfun$1(Run.scala:270)
	dotty.tools.dotc.Run.compileUnits$$anonfun$adapted$1(Run.scala:279)
	dotty.tools.dotc.util.Stats$.maybeMonitored(Stats.scala:67)
	dotty.tools.dotc.Run.compileUnits(Run.scala:279)
	dotty.tools.dotc.Run.compileSources(Run.scala:194)
	dotty.tools.dotc.interactive.InteractiveDriver.run(InteractiveDriver.scala:165)
	scala.meta.internal.pc.MetalsDriver.run(MetalsDriver.scala:45)
	scala.meta.internal.pc.WithCompilationUnit.<init>(WithCompilationUnit.scala:28)
	scala.meta.internal.pc.SimpleCollector.<init>(PcCollector.scala:373)
	scala.meta.internal.pc.PcSemanticTokensProvider$Collector$.<init>(PcSemanticTokensProvider.scala:61)
	scala.meta.internal.pc.PcSemanticTokensProvider.Collector$lzyINIT1(PcSemanticTokensProvider.scala:61)
	scala.meta.internal.pc.PcSemanticTokensProvider.Collector(PcSemanticTokensProvider.scala:61)
	scala.meta.internal.pc.PcSemanticTokensProvider.provide(PcSemanticTokensProvider.scala:90)
	scala.meta.internal.pc.ScalaPresentationCompiler.semanticTokens$$anonfun$1(ScalaPresentationCompiler.scala:109)
```
#### Short summary: 

java.lang.AssertionError: assertion failed